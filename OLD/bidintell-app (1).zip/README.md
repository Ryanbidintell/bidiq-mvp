# BidIntell

**Decision Intelligence for Construction Bidding**

BidIntell helps construction subcontractors make smarter GO/NO-GO bid decisions with explainable scoring. Upload your bid documents, get a BidIndex Score (0-100) with clear reasoning, and build your system of record for bid decisions.

## Features

- 📊 **BidIndex Score** - Explainable 0-100 scoring with GO / REVIEW / PASS guidance
- 📍 **Location Analysis** - Distance calculation from your office to project
- 🔑 **Keyword Detection** - Find good terms and risk flags in bid documents
- 🏢 **GC Relationship Tracking** - Track win rates with each general contractor
- 🔧 **Trade Match** - Verify your CSI divisions appear in specs

## Tech Stack

- **Frontend:** HTML/CSS/JavaScript (single-file app)
- **Backend:** Supabase (PostgreSQL, Auth, Storage)
- **AI:** Claude API for document extraction
- **Hosting:** Vercel/Netlify (recommended)

## Setup

### 1. Clone the repo
```bash
git clone https://github.com/yourusername/bidintell.git
cd bidintell
```

### 2. Create Supabase Project
1. Go to [supabase.com](https://supabase.com)
2. Create a new project
3. Run the schema in `supabase/schema.sql` via SQL Editor

### 3. Update Configuration
Edit `index.html` and update:
```javascript
const SUPABASE_URL = 'your-project-url';
const SUPABASE_ANON_KEY = 'your-anon-key';
const ADMIN_EMAIL = 'your-admin-email';
```

### 4. Deploy
Deploy to Vercel or Netlify, or run locally:
```bash
# Simple local server
npx serve .
```

## File Structure

```
bidintell/
├── index.html              # Main application (landing + app)
├── supabase/
│   └── schema.sql          # Database schema
├── docs/
│   └── email-templates.md  # Beta approval emails
└── README.md
```

## Branding Guidelines

| Term | Usage |
|------|-------|
| **BidIntell** | Company/platform name |
| **BidIndex** | Scoring system |
| **BidIndex Score** | The 0-100 score output |
| **GO / REVIEW / PASS** | Decision guidance |

**Never use:** BidIQ, Bid IQ, or any "IQ" variation

## License

Proprietary - © 2026 BidIntell, LLC

## Contact

- Email: hello@bidintell.ai
- Website: https://bidintell.ai
