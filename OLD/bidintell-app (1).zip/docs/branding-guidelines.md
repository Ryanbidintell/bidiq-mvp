# BidIntell Branding & Terminology Standards

**Version:** 1.0  
**Last Updated:** January 28, 2026

---

## Company Information

| Field | Value |
|-------|-------|
| Legal Entity | BidIntell, LLC |
| Brand Name | BidIntell |
| Domain | bidintell.ai |
| Contact Email | hello@bidintell.ai |

---

## Core Terminology

### Platform Name
- ✅ **BidIntell** - The company and platform
- ✅ **BidIntell.ai** - The website/domain
- ❌ Never: BidIQ, Bid IQ, or any "IQ" variation

### Scoring System
- ✅ **BidIndex** - The scoring methodology
- ✅ **BidIndex Score** - The numeric output (0-100)
- ❌ Never: BidIQ Score, IQ Score, or any "IQ" variation

### Decision Guidance
- ✅ **GO** - Score 80-100, strong fit
- ✅ **REVIEW** - Score 60-79, mixed signals
- ✅ **PASS** - Score 0-59, poor fit

---

## Category & Positioning

### Use These Phrases
- Decision Intelligence for Construction Bidding
- Explainable scoring
- System of record for bid decisions
- GO / REVIEW / PASS guidance

### Avoid These Phrases
- "Predicts who will win"
- "AI decides for you"
- "Automated bidding"
- "Smart bidding engine"
- Any comparison to "IQ" or intelligence quotient

---

## Correct Usage Examples

✅ **Correct:**
- "BidIntell analyzes bid documents and produces a BidIndex Score."
- "The BidIndex Score provides GO / REVIEW / PASS guidance."
- "Your BidIndex Score is 78 - REVIEW this opportunity carefully."
- "BidIntell is your system of record for bid decisions."

❌ **Incorrect:**
- "BidIQ Score" (uses IQ)
- "Bid IQ helps you decide" (uses IQ)
- "Our IQ-based scoring system" (uses IQ)
- "BidIntell predicts winners" (overpromises)

---

## Visual Identity

### Logo
- Primary: 📊 BidIntell
- Icon only: 📊

### Colors
- Primary Accent: #3b82f6 (Blue)
- Secondary: #8b5cf6 (Purple gradient)
- Success (GO): #22c55e
- Warning (REVIEW): #f59e0b
- Danger (PASS): #ef4444

### Typography
- Headings: Plus Jakarta Sans (800 weight)
- Body: Plus Jakarta Sans (400-600 weight)
- Monospace/Numbers: Space Mono

---

## Implementation Checklist

When reviewing any content, verify:

- [ ] No instances of "IQ" in branding
- [ ] "BidIndex Score" is the only score term
- [ ] Company referred to as "BidIntell" or "BidIntell, LLC"
- [ ] Decision guidance uses GO / REVIEW / PASS
- [ ] No overpromising language about prediction accuracy
- [ ] Footer shows "© 2026 BidIntell, LLC"

---

## Rationale

The branding change from "BidIQ" to "BidIntell/BidIndex" was made to:
1. Avoid potential trademark conflicts with "IQ" in adjacent software markets
2. Better position the product as "decision intelligence" rather than an AI gimmick
3. Create a more professional, construction-appropriate brand identity

---

## Questions?

Contact: hello@bidintell.ai
